--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.5
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Italian_Italy.1252';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: databaseprog; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA databaseprog;


ALTER SCHEMA databaseprog OWNER TO postgres;

--
-- Name: addlikereview(); Type: FUNCTION; Schema: databaseprog; Owner: postgres
--

CREATE FUNCTION databaseprog.addlikereview() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN

	if new.tipo is true then
		update databaseprog.recensione set numero_mi_piace = numero_mi_piace + 1 where id = new.recensione;
	else
		update databaseprog.recensione set numero_non_mi_piace = numero_non_mi_piace + 1 where id = new.recensione;
	end if;

 	RETURN new; 

END;
$$;


ALTER FUNCTION databaseprog.addlikereview() OWNER TO postgres;

--
-- Name: removelikereview(); Type: FUNCTION; Schema: databaseprog; Owner: postgres
--

CREATE FUNCTION databaseprog.removelikereview() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN

	if old.tipo is true then
		update databaseprog.recensione set numero_mi_piace = numero_mi_piace - 1 where id = old.recensione;
	else
		update databaseprog.recensione set numero_non_mi_piace = numero_non_mi_piace - 1 where id = old.recensione;
	end if;

 	RETURN old; 

END;
$$;


ALTER FUNCTION databaseprog.removelikereview() OWNER TO postgres;

--
-- Name: trigger_function(); Type: FUNCTION; Schema: databaseprog; Owner: postgres
--

CREATE FUNCTION databaseprog.trigger_function() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN

	if new.tipo is true then
		update databaseprog.commento set numero_mi_piace = numero_mi_piace + 1 where id = new.commento;
	else
		update databaseprog.commento set numero_non_mi_piace = numero_non_mi_piace + 1 where id = new.commento;
	end if;

 	RETURN new; 

END;
$$;


ALTER FUNCTION databaseprog.trigger_function() OWNER TO postgres;

--
-- Name: trigger_functionremove(); Type: FUNCTION; Schema: databaseprog; Owner: postgres
--

CREATE FUNCTION databaseprog.trigger_functionremove() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN

	if old.tipo is true then
		update databaseprog.commento set numero_mi_piace = numero_mi_piace - 1 where id = old.commento;
	else
		update databaseprog.commento set numero_non_mi_piace = numero_non_mi_piace - 1 where id = old.commento;
	end if;

 	RETURN old; 

END;
$$;


ALTER FUNCTION databaseprog.trigger_functionremove() OWNER TO postgres;

--
-- Name: updatelikeordislike(integer, boolean, character varying); Type: FUNCTION; Schema: databaseprog; Owner: postgres
--

CREATE FUNCTION databaseprog.updatelikeordislike(commentid integer, islike boolean, username character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
declare currentFeedback boolean;
begin
	select tipo into currentFeedback from databaseprog.feedback_commenti where utente = username and commento = commentID;
	if currentFeedback != isLike or currentFeedback is null then
		INSERT INTO databaseprog.feedback_commenti
			VALUES(username, commentID, isLike) 
			ON CONFLICT (utente, commento) 
			DO 
	   	UPDATE SET tipo = isLike;
	   	return true;
	else
		delete from databaseprog.feedback_commenti where utente = username;
		return false;
	end if;
END;
$$;


ALTER FUNCTION databaseprog.updatelikeordislike(commentid integer, islike boolean, username character varying) OWNER TO postgres;

--
-- Name: updatelikeordislikereview(integer, boolean, character varying); Type: FUNCTION; Schema: databaseprog; Owner: postgres
--

CREATE FUNCTION databaseprog.updatelikeordislikereview(reviewid integer, islike boolean, username character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
declare currentFeedback boolean;
begin
	select tipo into currentFeedback from databaseprog.feedback_recensione where utente = username and recensione = reviewID;
	if currentFeedback != isLike or currentFeedback is null then
		INSERT INTO databaseprog.feedback_recensione
			VALUES(username, reviewID, isLike) 
			ON CONFLICT (utente, recensione) 
			DO 
	   	UPDATE SET tipo = isLike;
	   	return true;
	else
		delete from databaseprog.feedback_recensione where utente = username;
		return false;
	end if;
END;
$$;


ALTER FUNCTION databaseprog.updatelikeordislikereview(reviewid integer, islike boolean, username character varying) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: commento; Type: TABLE; Schema: databaseprog; Owner: postgres
--

CREATE TABLE databaseprog.commento (
    id integer NOT NULL,
    contenuto character varying NOT NULL,
    numero_mi_piace integer DEFAULT 0 NOT NULL,
    numero_non_mi_piace integer DEFAULT 0 NOT NULL,
    recensione integer NOT NULL,
    utente character varying(50) NOT NULL,
    data timestamp without time zone NOT NULL
);


ALTER TABLE databaseprog.commento OWNER TO postgres;

--
-- Name: commento_id_seq; Type: SEQUENCE; Schema: databaseprog; Owner: postgres
--

CREATE SEQUENCE databaseprog.commento_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE databaseprog.commento_id_seq OWNER TO postgres;

--
-- Name: commento_id_seq; Type: SEQUENCE OWNED BY; Schema: databaseprog; Owner: postgres
--

ALTER SEQUENCE databaseprog.commento_id_seq OWNED BY databaseprog.commento.id;


--
-- Name: feedback_commenti; Type: TABLE; Schema: databaseprog; Owner: postgres
--

CREATE TABLE databaseprog.feedback_commenti (
    utente character varying(50) NOT NULL,
    commento integer NOT NULL,
    tipo boolean NOT NULL
);


ALTER TABLE databaseprog.feedback_commenti OWNER TO postgres;

--
-- Name: feedback_recensione; Type: TABLE; Schema: databaseprog; Owner: postgres
--

CREATE TABLE databaseprog.feedback_recensione (
    utente character varying(50) NOT NULL,
    recensione integer NOT NULL,
    tipo boolean NOT NULL
);


ALTER TABLE databaseprog.feedback_recensione OWNER TO postgres;

--
-- Name: feedbacklist_id_seq; Type: SEQUENCE; Schema: databaseprog; Owner: postgres
--

CREATE SEQUENCE databaseprog.feedbacklist_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE databaseprog.feedbacklist_id_seq OWNER TO postgres;

--
-- Name: gioco; Type: TABLE; Schema: databaseprog; Owner: postgres
--

CREATE TABLE databaseprog.gioco (
    id integer NOT NULL,
    genere character varying NOT NULL,
    titolo character varying,
    immagine character varying
);


ALTER TABLE databaseprog.gioco OWNER TO postgres;

--
-- Name: recensione; Type: TABLE; Schema: databaseprog; Owner: postgres
--

CREATE TABLE databaseprog.recensione (
    id integer NOT NULL,
    titolo character varying(50) NOT NULL,
    contenuto character varying NOT NULL,
    voto integer NOT NULL,
    numero_mi_piace integer DEFAULT 0 NOT NULL,
    numero_non_mi_piace integer DEFAULT 0 NOT NULL,
    utente character varying(50) NOT NULL,
    gioco integer NOT NULL,
    data timestamp without time zone NOT NULL
);


ALTER TABLE databaseprog.recensione OWNER TO postgres;

--
-- Name: recensione_id_seq; Type: SEQUENCE; Schema: databaseprog; Owner: postgres
--

CREATE SEQUENCE databaseprog.recensione_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE databaseprog.recensione_id_seq OWNER TO postgres;

--
-- Name: recensione_id_seq; Type: SEQUENCE OWNED BY; Schema: databaseprog; Owner: postgres
--

ALTER SEQUENCE databaseprog.recensione_id_seq OWNED BY databaseprog.recensione.id;


--
-- Name: segnalazione; Type: TABLE; Schema: databaseprog; Owner: postgres
--

CREATE TABLE databaseprog.segnalazione (
    recensione integer NOT NULL,
    utente character varying(50) NOT NULL,
    motivazione character varying NOT NULL
);


ALTER TABLE databaseprog.segnalazione OWNER TO postgres;

--
-- Name: utente; Type: TABLE; Schema: databaseprog; Owner: postgres
--

CREATE TABLE databaseprog.utente (
    username character varying(50) NOT NULL,
    email character varying(50) NOT NULL,
    password character varying NOT NULL,
    amministratore boolean DEFAULT false NOT NULL,
    bandito boolean DEFAULT false NOT NULL
);


ALTER TABLE databaseprog.utente OWNER TO postgres;

--
-- Name: wishlist; Type: TABLE; Schema: databaseprog; Owner: postgres
--

CREATE TABLE databaseprog.wishlist (
    utente character varying(50) NOT NULL,
    gioco integer NOT NULL
);


ALTER TABLE databaseprog.wishlist OWNER TO postgres;

--
-- Name: commento id; Type: DEFAULT; Schema: databaseprog; Owner: postgres
--

ALTER TABLE ONLY databaseprog.commento ALTER COLUMN id SET DEFAULT nextval('databaseprog.commento_id_seq'::regclass);


--
-- Name: recensione id; Type: DEFAULT; Schema: databaseprog; Owner: postgres
--

ALTER TABLE ONLY databaseprog.recensione ALTER COLUMN id SET DEFAULT nextval('databaseprog.recensione_id_seq'::regclass);


--
-- Data for Name: commento; Type: TABLE DATA; Schema: databaseprog; Owner: postgres
--

COPY databaseprog.commento (id, contenuto, numero_mi_piace, numero_non_mi_piace, recensione, utente, data) FROM stdin;
\.
COPY databaseprog.commento (id, contenuto, numero_mi_piace, numero_non_mi_piace, recensione, utente, data) FROM '$$PATH$$/3384.dat';

--
-- Data for Name: feedback_commenti; Type: TABLE DATA; Schema: databaseprog; Owner: postgres
--

COPY databaseprog.feedback_commenti (utente, commento, tipo) FROM stdin;
\.
COPY databaseprog.feedback_commenti (utente, commento, tipo) FROM '$$PATH$$/3386.dat';

--
-- Data for Name: feedback_recensione; Type: TABLE DATA; Schema: databaseprog; Owner: postgres
--

COPY databaseprog.feedback_recensione (utente, recensione, tipo) FROM stdin;
\.
COPY databaseprog.feedback_recensione (utente, recensione, tipo) FROM '$$PATH$$/3387.dat';

--
-- Data for Name: gioco; Type: TABLE DATA; Schema: databaseprog; Owner: postgres
--

COPY databaseprog.gioco (id, genere, titolo, immagine) FROM stdin;
\.
COPY databaseprog.gioco (id, genere, titolo, immagine) FROM '$$PATH$$/3389.dat';

--
-- Data for Name: recensione; Type: TABLE DATA; Schema: databaseprog; Owner: postgres
--

COPY databaseprog.recensione (id, titolo, contenuto, voto, numero_mi_piace, numero_non_mi_piace, utente, gioco, data) FROM stdin;
\.
COPY databaseprog.recensione (id, titolo, contenuto, voto, numero_mi_piace, numero_non_mi_piace, utente, gioco, data) FROM '$$PATH$$/3390.dat';

--
-- Data for Name: segnalazione; Type: TABLE DATA; Schema: databaseprog; Owner: postgres
--

COPY databaseprog.segnalazione (recensione, utente, motivazione) FROM stdin;
\.
COPY databaseprog.segnalazione (recensione, utente, motivazione) FROM '$$PATH$$/3392.dat';

--
-- Data for Name: utente; Type: TABLE DATA; Schema: databaseprog; Owner: postgres
--

COPY databaseprog.utente (username, email, password, amministratore, bandito) FROM stdin;
\.
COPY databaseprog.utente (username, email, password, amministratore, bandito) FROM '$$PATH$$/3393.dat';

--
-- Data for Name: wishlist; Type: TABLE DATA; Schema: databaseprog; Owner: postgres
--

COPY databaseprog.wishlist (utente, gioco) FROM stdin;
\.
COPY databaseprog.wishlist (utente, gioco) FROM '$$PATH$$/3394.dat';

--
-- Name: commento_id_seq; Type: SEQUENCE SET; Schema: databaseprog; Owner: postgres
--

SELECT pg_catalog.setval('databaseprog.commento_id_seq', 196, true);


--
-- Name: feedbacklist_id_seq; Type: SEQUENCE SET; Schema: databaseprog; Owner: postgres
--

SELECT pg_catalog.setval('databaseprog.feedbacklist_id_seq', 3, true);


--
-- Name: recensione_id_seq; Type: SEQUENCE SET; Schema: databaseprog; Owner: postgres
--

SELECT pg_catalog.setval('databaseprog.recensione_id_seq', 110, true);


--
-- Name: commento commento_pk; Type: CONSTRAINT; Schema: databaseprog; Owner: postgres
--

ALTER TABLE ONLY databaseprog.commento
    ADD CONSTRAINT commento_pk PRIMARY KEY (id);


--
-- Name: feedback_commenti feedback_commenti_pk; Type: CONSTRAINT; Schema: databaseprog; Owner: postgres
--

ALTER TABLE ONLY databaseprog.feedback_commenti
    ADD CONSTRAINT feedback_commenti_pk PRIMARY KEY (utente, commento);


--
-- Name: feedback_recensione feedback_recensione_pk; Type: CONSTRAINT; Schema: databaseprog; Owner: postgres
--

ALTER TABLE ONLY databaseprog.feedback_recensione
    ADD CONSTRAINT feedback_recensione_pk PRIMARY KEY (utente, recensione);


--
-- Name: gioco gioco_pk; Type: CONSTRAINT; Schema: databaseprog; Owner: postgres
--

ALTER TABLE ONLY databaseprog.gioco
    ADD CONSTRAINT gioco_pk PRIMARY KEY (id);


--
-- Name: recensione recensione_pk; Type: CONSTRAINT; Schema: databaseprog; Owner: postgres
--

ALTER TABLE ONLY databaseprog.recensione
    ADD CONSTRAINT recensione_pk PRIMARY KEY (id);


--
-- Name: recensione recensione_un; Type: CONSTRAINT; Schema: databaseprog; Owner: postgres
--

ALTER TABLE ONLY databaseprog.recensione
    ADD CONSTRAINT recensione_un UNIQUE (utente, gioco);


--
-- Name: segnalazione segnalazione_pk; Type: CONSTRAINT; Schema: databaseprog; Owner: postgres
--

ALTER TABLE ONLY databaseprog.segnalazione
    ADD CONSTRAINT segnalazione_pk PRIMARY KEY (recensione, utente);


--
-- Name: utente utente_pk; Type: CONSTRAINT; Schema: databaseprog; Owner: postgres
--

ALTER TABLE ONLY databaseprog.utente
    ADD CONSTRAINT utente_pk PRIMARY KEY (username);


--
-- Name: utente utente_un; Type: CONSTRAINT; Schema: databaseprog; Owner: postgres
--

ALTER TABLE ONLY databaseprog.utente
    ADD CONSTRAINT utente_un UNIQUE (email);


--
-- Name: wishlist wishlist_pk; Type: CONSTRAINT; Schema: databaseprog; Owner: postgres
--

ALTER TABLE ONLY databaseprog.wishlist
    ADD CONSTRAINT wishlist_pk PRIMARY KEY (utente, gioco);


--
-- Name: feedback_recensione feedbackdeletereview; Type: TRIGGER; Schema: databaseprog; Owner: postgres
--

CREATE TRIGGER feedbackdeletereview AFTER DELETE OR UPDATE ON databaseprog.feedback_recensione FOR EACH ROW EXECUTE FUNCTION databaseprog.removelikereview();


--
-- Name: feedback_recensione feedbackinsertreview; Type: TRIGGER; Schema: databaseprog; Owner: postgres
--

CREATE TRIGGER feedbackinsertreview AFTER INSERT OR UPDATE ON databaseprog.feedback_recensione FOR EACH ROW EXECUTE FUNCTION databaseprog.addlikereview();


--
-- Name: feedback_commenti prova; Type: TRIGGER; Schema: databaseprog; Owner: postgres
--

CREATE TRIGGER prova AFTER INSERT OR UPDATE ON databaseprog.feedback_commenti FOR EACH ROW EXECUTE FUNCTION databaseprog.trigger_function();


--
-- Name: feedback_commenti provarem; Type: TRIGGER; Schema: databaseprog; Owner: postgres
--

CREATE TRIGGER provarem AFTER DELETE OR UPDATE ON databaseprog.feedback_commenti FOR EACH ROW EXECUTE FUNCTION databaseprog.trigger_functionremove();


--
-- Name: commento commento_fk_recensione; Type: FK CONSTRAINT; Schema: databaseprog; Owner: postgres
--

ALTER TABLE ONLY databaseprog.commento
    ADD CONSTRAINT commento_fk_recensione FOREIGN KEY (recensione) REFERENCES databaseprog.recensione(id) ON DELETE CASCADE;


--
-- Name: commento commento_fk_utente; Type: FK CONSTRAINT; Schema: databaseprog; Owner: postgres
--

ALTER TABLE ONLY databaseprog.commento
    ADD CONSTRAINT commento_fk_utente FOREIGN KEY (utente) REFERENCES databaseprog.utente(username) ON DELETE CASCADE;


--
-- Name: feedback_commenti feedback_commenti_fk_commento; Type: FK CONSTRAINT; Schema: databaseprog; Owner: postgres
--

ALTER TABLE ONLY databaseprog.feedback_commenti
    ADD CONSTRAINT feedback_commenti_fk_commento FOREIGN KEY (commento) REFERENCES databaseprog.commento(id) ON DELETE CASCADE;


--
-- Name: feedback_commenti feedback_commenti_fk_utente; Type: FK CONSTRAINT; Schema: databaseprog; Owner: postgres
--

ALTER TABLE ONLY databaseprog.feedback_commenti
    ADD CONSTRAINT feedback_commenti_fk_utente FOREIGN KEY (utente) REFERENCES databaseprog.utente(username) ON DELETE CASCADE;


--
-- Name: feedback_recensione feedback_recensione_fk_recensione; Type: FK CONSTRAINT; Schema: databaseprog; Owner: postgres
--

ALTER TABLE ONLY databaseprog.feedback_recensione
    ADD CONSTRAINT feedback_recensione_fk_recensione FOREIGN KEY (recensione) REFERENCES databaseprog.recensione(id) ON DELETE CASCADE;


--
-- Name: feedback_recensione feedback_recensione_fk_utente; Type: FK CONSTRAINT; Schema: databaseprog; Owner: postgres
--

ALTER TABLE ONLY databaseprog.feedback_recensione
    ADD CONSTRAINT feedback_recensione_fk_utente FOREIGN KEY (utente) REFERENCES databaseprog.utente(username) ON DELETE CASCADE;


--
-- Name: recensione recensione_fk_gioco; Type: FK CONSTRAINT; Schema: databaseprog; Owner: postgres
--

ALTER TABLE ONLY databaseprog.recensione
    ADD CONSTRAINT recensione_fk_gioco FOREIGN KEY (gioco) REFERENCES databaseprog.gioco(id) ON DELETE CASCADE;


--
-- Name: recensione recensione_fk_utente; Type: FK CONSTRAINT; Schema: databaseprog; Owner: postgres
--

ALTER TABLE ONLY databaseprog.recensione
    ADD CONSTRAINT recensione_fk_utente FOREIGN KEY (utente) REFERENCES databaseprog.utente(username) ON DELETE CASCADE;


--
-- Name: segnalazione segnalazione_fk_recensione; Type: FK CONSTRAINT; Schema: databaseprog; Owner: postgres
--

ALTER TABLE ONLY databaseprog.segnalazione
    ADD CONSTRAINT segnalazione_fk_recensione FOREIGN KEY (recensione) REFERENCES databaseprog.recensione(id) ON DELETE CASCADE;


--
-- Name: segnalazione segnalazione_fk_utente; Type: FK CONSTRAINT; Schema: databaseprog; Owner: postgres
--

ALTER TABLE ONLY databaseprog.segnalazione
    ADD CONSTRAINT segnalazione_fk_utente FOREIGN KEY (utente) REFERENCES databaseprog.utente(username) ON DELETE CASCADE;


--
-- Name: wishlist wishlist_fk_gioco; Type: FK CONSTRAINT; Schema: databaseprog; Owner: postgres
--

ALTER TABLE ONLY databaseprog.wishlist
    ADD CONSTRAINT wishlist_fk_gioco FOREIGN KEY (gioco) REFERENCES databaseprog.gioco(id) ON DELETE CASCADE;


--
-- Name: wishlist wishlist_fk_utente; Type: FK CONSTRAINT; Schema: databaseprog; Owner: postgres
--

ALTER TABLE ONLY databaseprog.wishlist
    ADD CONSTRAINT wishlist_fk_utente FOREIGN KEY (utente) REFERENCES databaseprog.utente(username) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

